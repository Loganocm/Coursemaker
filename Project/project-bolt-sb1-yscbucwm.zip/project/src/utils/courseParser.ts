import { Course, Module, Flashcard, QuizQuestion } from '../types';

export function parseCourseText(text: string): Course {
  const lines = text.split('\n').map(line => line.trim());
  
  let course: Course = {
    title: '',
    modules: []
  };
  
  let currentModule: Partial<Module> | null = null;
  let currentSection: 'notes' | 'flashcards' | 'quiz' | null = null;
  let currentContent: string[] = [];
  
  for (const line of lines) {
    // Skip empty lines
    if (line.length === 0) {
      continue;
    }
    
    // Course title
    if (line.startsWith('# ')) {
      const titlePart = line.substring(2);
      // Handle format like "# Course Title - The Essentials of..."
      course.title = titlePart.includes(' - ') ? titlePart.split(' - ')[1] : titlePart;
      continue;
    }
    
    // Module title
    if (line.startsWith('## ')) {
      // Save previous module if exists
      if (currentModule) {
        finishCurrentSection(currentModule, currentSection, currentContent);
        course.modules.push(currentModule as Module);
      }
      
      // Start new module
      const titlePart = line.substring(3);
      // Handle format like "## Module Title - Chapter 1: Introduction"
      const moduleTitle = titlePart.includes(' - ') ? titlePart.split(' - ')[1] : titlePart;
      currentModule = {
        id: generateId(),
        title: moduleTitle,
        notes: '',
        flashcards: [],
        quiz: []
      };
      currentSection = null;
      currentContent = [];
      continue;
    }
    
    // Section headers with content on same line
    if (line.startsWith('### ')) {
      // Finish previous section
      if (currentModule && currentSection) {
        finishCurrentSection(currentModule, currentSection, currentContent);
      }
      
      const fullLine = line.substring(4);
      const parts = fullLine.split(' - ');
      
      if (parts.length >= 2) {
        const sectionTitle = parts[0].toLowerCase();
        const content = parts.slice(1).join(' - '); // Rejoin in case there are multiple " - " in content
        
        if (sectionTitle === 'notes') {
          currentSection = 'notes';
          currentContent = [content];
        } else if (sectionTitle === 'flashcards') {
          currentSection = 'flashcards';
          currentContent = [content];
        } else if (sectionTitle === 'quiz') {
          currentSection = 'quiz';
          currentContent = [content];
        } else {
          currentSection = null;
          currentContent = [];
        }
      } else {
        // Handle section headers without content on same line
        const sectionTitle = fullLine.toLowerCase();
        if (sectionTitle === 'notes') {
          currentSection = 'notes';
        } else if (sectionTitle === 'flashcards') {
          currentSection = 'flashcards';
        } else if (sectionTitle === 'quiz') {
          currentSection = 'quiz';
        } else {
          currentSection = null;
        }
        currentContent = [];
      }
      continue;
    }
    
    // Content lines (for multi-line sections)
    if (currentSection && !line.startsWith('#')) {
      currentContent.push(line);
    }
  }
  
  // Finish last module
  if (currentModule) {
    finishCurrentSection(currentModule, currentSection, currentContent);
    course.modules.push(currentModule as Module);
  }
  
  return course;
}

function finishCurrentSection(
  module: Partial<Module>, 
  section: 'notes' | 'flashcards' | 'quiz' | null, 
  content: string[]
) {
  if (!section || !module || content.length === 0) return;
  
  const fullContent = content.join(' ').trim();
  
  switch (section) {
    case 'notes':
      module.notes = fullContent;
      break;
    case 'flashcards':
      module.flashcards = parseFlashcards([fullContent]);
      break;
    case 'quiz':
      module.quiz = parseQuiz([fullContent]);
      break;
  }
}

function parseFlashcards(content: string[]): Flashcard[] {
  const flashcards: Flashcard[] = [];
  const fullContent = content.join(' ');
  
  // Split by "Q:" to find individual flashcards
  const cardParts = fullContent.split(/Q:\s*/);
  
  for (let i = 1; i < cardParts.length; i++) { // Skip first empty part
    const cardContent = cardParts[i].trim();
    
    // Find the answer part
    const answerMatch = cardContent.match(/,\s*A:\s*(.+?)(?=,\s*Q:|$)/);
    if (answerMatch) {
      const question = cardContent.substring(0, cardContent.indexOf(', A:')).trim();
      const answer = answerMatch[1].trim();
      
      if (question && answer) {
        flashcards.push({
          id: generateId(),
          question: question,
          answer: answer
        });
      }
    }
  }
  
  return flashcards;
}

function parseQuiz(content: string[]): QuizQuestion[] {
  const questions: QuizQuestion[] = [];
  const fullContent = content.join(' ');
  
  // Split by "Q:" to find individual questions
  const questionParts = fullContent.split(/Q:\s*/);
  
  for (let i = 1; i < questionParts.length; i++) { // Skip first empty part
    const questionContent = questionParts[i].trim();
    
    // Extract question text (everything before the first option)
    const questionMatch = questionContent.match(/^(.+?),\s*A\)/);
    if (!questionMatch) continue;
    
    const questionText = questionMatch[1].trim();
    
    // Extract all options (A), B), C), D))
    const optionMatches = questionContent.match(/([A-D]\)\s*[^,]+)/g);
    if (!optionMatches || optionMatches.length < 2) continue;
    
    const options = optionMatches.map(option => {
      return option.substring(3).trim(); // Remove "A) ", "B) ", etc.
    });
    
    // Extract correct answer
    const correctMatch = questionContent.match(/CORRECT:\s*([A-D])/);
    if (!correctMatch) continue;
    
    const correctLetter = correctMatch[1];
    const correctAnswer = correctLetter.charCodeAt(0) - 'A'.charCodeAt(0);
    
    if (questionText && options.length > 0 && correctAnswer >= 0 && correctAnswer < options.length) {
      questions.push({
        id: generateId(),
        question: questionText,
        options: options,
        correctAnswer: correctAnswer
      });
    }
  }
  
  return questions;
}

function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}