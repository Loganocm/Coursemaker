import React from 'react';
import { CheckCircle, FileText } from 'lucide-react';
import { Module } from '../types';

interface ModuleNotesProps {
  module: Module;
  onComplete: () => void;
}

const ModuleNotes: React.FC<ModuleNotesProps> = ({ module, onComplete }) => {
  const formatNotes = (notes: string) => {
    const lines = notes.split('\n');
    const formatted: React.ReactNode[] = [];
    
    lines.forEach((line, index) => {
      if (line.trim() === '') {
        formatted.push(<br key={index} />);
      } else if (line.startsWith('- ')) {
        formatted.push(
          <li key={index} className="ml-4 mb-1">
            {line.substring(2)}
          </li>
        );
      } else if (line.endsWith(':')) {
        formatted.push(
          <h4 key={index} className="font-semibold text-gray-900 mt-4 mb-2">
            {line}
          </h4>
        );
      } else {
        formatted.push(
          <p key={index} className="mb-3 leading-relaxed">
            {line}
          </p>
        );
      }
    });
    
    return formatted;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-8">
      <div className="flex items-center mb-6">
        <FileText className="w-8 h-8 text-blue-600 mr-3" />
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{module.title}</h2>
          <p className="text-gray-600">Study Notes</p>
        </div>
      </div>

      <div className="prose max-w-none mb-8">
        <div className="bg-blue-50 rounded-lg p-6 text-gray-800 leading-relaxed">
          {formatNotes(module.notes)}
        </div>
      </div>

      <div className="flex justify-center">
        <button
          onClick={onComplete}
          className="flex items-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
        >
          <CheckCircle className="w-5 h-5 mr-2" />
          Mark as Complete
        </button>
      </div>
    </div>
  );
};

export default ModuleNotes;