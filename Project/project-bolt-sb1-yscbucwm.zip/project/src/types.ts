export interface Course {
  title: string;
  modules: Module[];
}

export interface Module {
  id: string;
  title: string;
  notes: string;
  flashcards: Flashcard[];
  quiz: QuizQuestion[];
}

export interface Flashcard {
  id: string;
  question: string;
  answer: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface UserProgress {
  courseId: string;
  currentModuleId: string;
  completedModules: string[];
  flashcardProgress: Record<string, boolean[]>;
  quizScores: Record<string, number>;
}