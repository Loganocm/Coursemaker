import React, { useState } from 'react';
import { Course } from './types';
import CourseCreator from './components/CourseCreator';
import CourseViewer from './components/CourseViewer';

function App() {
  const [currentCourse, setCurrentCourse] = useState<Course | null>(null);

  const handleCourseCreate = (course: Course) => {
    setCurrentCourse(course);
  };

  const handleBackToCourseCreator = () => {
    setCurrentCourse(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {currentCourse ? (
        <CourseViewer 
          course={currentCourse} 
          onBack={handleBackToCourseCreator}
        />
      ) : (
        <CourseCreator onCourseCreate={handleCourseCreate} />
      )}
    </div>
  );
}

export default App;